# SOP Documents Directory

Place your Standard Operating Procedures and other documents in this directory.

## Supported File Formats

- **PDF Files**: `.pdf`
- **Microsoft Word**: `.docx`, `.doc` 
- **Microsoft Excel**: `.xlsx`, `.xls`
- **Text Files**: `.txt`
- **Markdown**: `.md`

## Usage

1. Add your document files to this directory
2. Run: `python main.py update` (will automatically use this SOP directory)
3. Start the chatbot: `python main.py web` or `python main.py chat`

The system will recursively process all supported files in this directory and its subdirectories.

## Example Structure

```
SOP/
├── policies/
│   ├── security_policy.pdf
│   └── data_retention.docx
├── procedures/
│   ├── incident_response.md
│   └── backup_procedures.txt
└── guidelines/
    ├── coding_standards.pdf
    └── review_process.xlsx
```