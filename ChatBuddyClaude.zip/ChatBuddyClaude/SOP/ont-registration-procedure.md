# ONT Registration Procedure

## Overview
This document outlines the standard operating procedure for registering Optical Network Terminal (ONT) devices in the network management system.

## Prerequisites
- ONT device ID
- Physical location information
- Network VLAN assignment
- Connection speed requirements

## Registration Steps

### Step 1: Verify Device Information
Before registration, ensure you have:
- **Device ID**: Unique identifier (e.g., ONT-001, ONT-002)
- **Location**: Full physical address (Building, Floor, Room)
- **VLAN**: Assigned VLAN ID (typically 100-999)
- **Speed**: Connection speed (100Mbps, 1000Mbps, or 10Gbps)

### Step 2: Register Device
Use the registration system to add the ONT:
1. Access the device management interface
2. Select "Register New ONT"
3. Enter device information
4. Verify VLAN availability
5. Confirm registration

### Step 3: Configuration
After registration, the ONT requires initial configuration:
- **VLAN Configuration**: Set VLAN ID per network design
- **Speed Configuration**: Configure link speed
- **Quality of Service**: Apply QoS policies
- **Security Settings**: Enable security features

### Step 4: Testing
Perform the following tests:
1. Link connectivity test
2. Speed test (verify configured speed)
3. VLAN isolation test
4. End-to-end connectivity test

## Troubleshooting

### Device Not Responding
- Check physical connections
- Verify power supply
- Check VLAN configuration
- Review network logs

### Speed Issues
- Verify configured speed matches capability
- Check for network congestion
- Review QoS settings
- Test with different endpoints

### VLAN Issues
- Confirm VLAN exists in network
- Verify VLAN tagging
- Check switch port configuration
- Review VLAN routing

## Best Practices
- Always document the exact location
- Use standardized naming conventions (ONT-XXX)
- Keep VLAN assignments organized
- Perform immediate testing after registration
- Update inventory system promptly

## Example Registration
```
Device ID: ONT-1234
Location: Building A - Floor 2 - Room 201
VLAN: 150
Speed: 1000Mbps
Status: Active
```

## Contact Information
For assistance with ONT registration:
- Network Operations: netops@company.com
- Technical Support: support@company.com
- Emergency: 1-800-TECH-911


