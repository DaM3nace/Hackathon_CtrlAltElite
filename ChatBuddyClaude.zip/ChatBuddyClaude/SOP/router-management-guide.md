# Router Management Guide

## Overview
Comprehensive guide for managing router devices including registration, configuration, monitoring, and troubleshooting.

## Router Types
Our network uses the following router types:
- **Cisco ASR Series**: Core routers for main data centers
- **Juniper MX Series**: Edge routers for distribution
- **Cisco ISR Series**: Branch office routers
- **Arista 7000 Series**: Data center switching/routing

## Registration Procedure

### Initial Registration
When adding a new router to the network:

1. **Device Information**
   - Device ID (e.g., ROUTER-001)
   - Model and manufacturer
   - Firmware version
   - Serial number
   - Purchase date

2. **Location Details**
   - Data center or site name
   - Rack location
   - Physical connections
   - Power circuit information

3. **Network Configuration**
   - Management IP address
   - Routing protocols (BGP, OSPF, etc.)
   - Interface assignments
   - Access control lists

### Configuration Management

#### Standard Configuration Template
```
hostname [ROUTER-ID]
!
ip routing
!
interface GigabitEthernet0/0
  description Uplink to Core
  ip address [IP] [MASK]
  no shutdown
!
router bgp [ASN]
  neighbor [IP] remote-as [ASN]
!
```

#### Firmware Management
- Check current firmware: `show version`
- Recommended versions:
  - Cisco ASR: v15.6 or later
  - Juniper MX: v18.4 or later
  - Cisco ISR: v16.12 or later

### Monitoring and Status Checks

#### Health Check Commands
```bash
# Cisco
show ip interface brief
show ip route
show processes cpu
show memory

# Juniper
show interfaces terse
show route summary
show chassis routing-engine
```

#### Key Metrics to Monitor
- CPU utilization (< 70% normal)
- Memory usage (< 80% normal)
- Interface errors
- BGP session status
- Temperature sensors

### Configuration Push Procedure

When pushing new configurations:

1. **Backup Current Config**
   ```
   copy running-config backup-config-[DATE]
   ```

2. **Apply New Configuration**
   - Review changes in staging environment
   - Schedule maintenance window
   - Apply configuration during low-traffic period
   - Verify changes immediately

3. **Validation**
   - Test all routing protocols
   - Verify interface status
   - Check BGP/OSPF neighbors
   - Perform connectivity tests

### Troubleshooting

#### Router Not Responding
- Check physical power
- Verify console connectivity
- Review system logs
- Check for software crashes

#### Routing Issues
- Verify routing protocol configuration
- Check neighbor relationships
- Review routing tables
- Validate access lists

#### Performance Problems
- Check CPU and memory
- Review interface statistics
- Analyze traffic patterns
- Look for routing loops

#### BGP Issues
- Verify neighbor configuration
- Check AS numbers
- Review route filters
- Validate MD5 authentication

### Maintenance Procedures

#### Regular Maintenance Tasks
- **Weekly**: Review logs and alerts
- **Monthly**: Firmware updates check
- **Quarterly**: Performance review
- **Annually**: Hardware refresh evaluation

#### Emergency Procedures
1. Isolate affected router
2. Fail over to redundant path
3. Document issue details
4. Contact vendor support if needed
5. Apply fix or replacement
6. Test thoroughly before returning to service

## Best Practices

### Configuration Management
- Always use version control for configs
- Document all changes
- Test in lab before production
- Maintain rollback configurations

### Security
- Change default passwords immediately
- Enable AAA authentication
- Use encrypted management protocols
- Regularly update ACLs

### Documentation
- Keep network diagrams updated
- Document all connections
- Maintain runbook procedures
- Record configuration changes

## Emergency Contacts
- Network Operations Center: noc@company.com
- Cisco TAC: 1-800-553-2447
- Juniper JTAC: 1-888-314-5822
- Internal Emergency: ext. 9111


