# IT Security Policy

## Overview
This document outlines the IT security policies and procedures for our organization.

## Password Requirements
- Passwords must be at least 12 characters long
- Must contain uppercase letters, lowercase letters, numbers, and special characters
- Passwords must be changed every 90 days
- Cannot reuse the last 12 passwords

## Access Control
- All employees must use multi-factor authentication
- Access rights should follow the principle of least privilege
- Regular access reviews must be conducted quarterly

## Data Protection
- All sensitive data must be encrypted in transit and at rest
- Personal data must be handled according to GDPR requirements
- Data backups must be performed daily and tested monthly

## Incident Response
- All security incidents must be reported within 1 hour
- The incident response team consists of IT, Security, and Management
- Post-incident reviews must be conducted within 48 hours

## Training
- Security awareness training is required annually
- New employees must complete security training within 30 days
- Phishing simulation exercises are conducted monthly