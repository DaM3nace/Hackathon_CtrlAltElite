
-- Databricks Reporting Queries for Conversation Analysis

-- 1. Daily conversation volume
SELECT 
    date,
    COUNT(*) as total_conversations,
    COUNT(DISTINCT session_id) as unique_sessions,
    COUNT(DISTINCT user_id) as unique_users,
    AVG(response_time_ms) as avg_response_time_ms,
    AVG(query_length) as avg_query_length,
    AVG(response_length) as avg_response_length
FROM hackathon_ctrl_alt_elite.documents.DG_CONVERSATION_METRICS
GROUP BY date
ORDER BY date DESC;

-- 2. Most common queries (by similarity)
SELECT 
    user_query,
    COUNT(*) as frequency,
    AVG(response_time_ms) as avg_response_time,
    AVG(num_sources) as avg_sources_used
FROM hackathon_ctrl_alt_elite.documents.DG_CONVERSATIONS
GROUP BY user_query
HAVING COUNT(*) > 1
ORDER BY frequency DESC
LIMIT 20;

-- 3. Source document usage analysis
SELECT 
    file_name,
    COUNT(*) as times_referenced,
    AVG(similarity_score) as avg_similarity,
    COUNT(DISTINCT conversation_id) as unique_conversations
FROM hackathon_ctrl_alt_elite.documents.DG_CONVERSATION_SOURCES
GROUP BY file_name
ORDER BY times_referenced DESC;

-- 4. User engagement patterns
SELECT 
    user_id,
    COUNT(*) as total_queries,
    COUNT(DISTINCT session_id) as sessions,
    MIN(timestamp) as first_interaction,
    MAX(timestamp) as last_interaction,
    AVG(query_length) as avg_query_length
FROM hackathon_ctrl_alt_elite.documents.DG_CONVERSATIONS
WHERE user_id != 'anonymous'
GROUP BY user_id
ORDER BY total_queries DESC;

-- 5. Performance metrics over time
SELECT 
    DATE_TRUNC('hour', timestamp) as hour,
    COUNT(*) as conversations_per_hour,
    AVG(response_time_ms) as avg_response_time,
    PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY response_time_ms) as p95_response_time,
    MAX(response_time_ms) as max_response_time
FROM hackathon_ctrl_alt_elite.documents.DG_CONVERSATIONS
GROUP BY DATE_TRUNC('hour', timestamp)
ORDER BY hour DESC
LIMIT 24;

-- 6. Quality metrics by source relevance
SELECT 
    CASE 
        WHEN avg_similarity >= 0.8 THEN 'High Relevance (0.8+)'
        WHEN avg_similarity >= 0.6 THEN 'Medium Relevance (0.6-0.8)'
        WHEN avg_similarity >= 0.4 THEN 'Low Relevance (0.4-0.6)'
        ELSE 'Very Low Relevance (<0.4)'
    END as relevance_tier,
    COUNT(*) as conversations,
    AVG(response_length) as avg_response_length
FROM (
    SELECT 
        conversation_id,
        AVG(similarity_score) as avg_similarity,
        MAX(response_length) as response_length
    FROM hackathon_ctrl_alt_elite.documents.DG_CONVERSATION_SOURCES s
    JOIN hackathon_ctrl_alt_elite.documents.DG_CONVERSATIONS c ON s.conversation_id = c.conversation_id
    GROUP BY s.conversation_id
) subq
GROUP BY 
    CASE 
        WHEN avg_similarity >= 0.8 THEN 'High Relevance (0.8+)'
        WHEN avg_similarity >= 0.6 THEN 'Medium Relevance (0.6-0.8)'
        WHEN avg_similarity >= 0.4 THEN 'Low Relevance (0.4-0.6)'
        ELSE 'Very Low Relevance (<0.4)'
    END
ORDER BY conversations DESC;

-- 7. Session analysis
SELECT 
    session_id,
    COUNT(*) as interactions_per_session,
    MIN(timestamp) as session_start,
    MAX(timestamp) as session_end,
    DATEDIFF(SECOND, MIN(timestamp), MAX(timestamp)) as session_duration_seconds,
    AVG(response_time_ms) as avg_response_time
FROM hackathon_ctrl_alt_elite.documents.DG_CONVERSATIONS
GROUP BY session_id
HAVING COUNT(*) > 1
ORDER BY interactions_per_session DESC
LIMIT 20;
