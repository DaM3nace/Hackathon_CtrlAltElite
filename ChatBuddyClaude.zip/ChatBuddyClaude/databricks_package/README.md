
# Databricks Conversation Analytics Package

This package contains conversation data and SQL scripts for importing into Databricks.

## Tables Created (DG Prefix)
- **DG_CONVERSATIONS**: Main conversation records
- **DG_CONVERSATION_SOURCES**: Document sources used for each response  
- **DG_CONVERSATION_METRICS**: Metrics for reporting and analysis

## Files Included
- `csv_data/`: CSV files for data import
- `01_create_tables.sql`: DDL statements to create tables
- `02_insert_data.sql`: INSERT statements for data (alternative to CSV)
- `03_reporting_queries.sql`: Pre-built analytics queries

## Import Instructions

### Option 1: CSV Import (Recommended)
1. Run `01_create_tables.sql` in Databricks to create tables
2. Use Databricks Data Import wizard to import CSV files:
   - Upload `DG_CONVERSATIONS.csv` to `hackathon_ctrl_alt_elite.documents.DG_CONVERSATIONS`
   - Upload `DG_CONVERSATION_SOURCES.csv` to `hackathon_ctrl_alt_elite.documents.DG_CONVERSATION_SOURCES`
   - Upload `DG_CONVERSATION_METRICS.csv` to `hackathon_ctrl_alt_elite.documents.DG_CONVERSATION_METRICS`

### Option 2: SQL Import
1. Run `01_create_tables.sql` to create tables
2. Run `02_insert_data.sql` to insert data

### Analytics
- Run queries from `03_reporting_queries.sql` for insights
- Create dashboards using the DG tables
- Set up scheduled reports

## Data Summary
- Total Conversations: 20
- Export Timestamp: 2025-11-17T23:06:50.489405
- Tables: DG_CONVERSATIONS, DG_CONVERSATION_SOURCES, DG_CONVERSATION_METRICS
