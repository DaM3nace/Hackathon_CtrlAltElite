
-- Create Databricks tables for conversation logging with DG prefix

-- Main conversations table
CREATE TABLE IF NOT EXISTS DG_CONVERSATIONS (
    conversation_id STRING,
    session_id STRING,
    user_id STRING,
    timestamp TIMESTAMP,
    user_query STRING,
    bot_response STRING,
    query_length INT,
    response_length INT,
    num_sources INT,
    response_time_ms DOUBLE,
    metadata STRING,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
) USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

-- Conversation sources table
CREATE TABLE IF NOT EXISTS DG_CONVERSATION_SOURCES (
    conversation_id STRING,
    source_rank INT,
    file_name STRING,
    file_path STRING,
    similarity_score DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
) USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

-- Conversation metrics table for reporting
CREATE TABLE IF NOT EXISTS DG_CONVERSATION_METRICS (
    conversation_id STRING,
    session_id STRING,
    user_id STRING,
    date DATE,
    query_length INT,
    response_length INT,
    response_time_ms DOUBLE,
    num_sources_used INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
) USING DELTA
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true');

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_dg_conv_session ON DG_CONVERSATIONS (session_id);
CREATE INDEX IF NOT EXISTS idx_dg_conv_timestamp ON DG_CONVERSATIONS (timestamp);
CREATE INDEX IF NOT EXISTS idx_dg_metrics_date ON DG_CONVERSATION_METRICS (date);
